%% Read swaps from spreadsheet.
clear all; close all; clc;

swapFile = 'cva-swap-portfolio3.xls'; % modify this
swaps = readtable(swapFile,'Sheet','Swap Portfolio');
swaps.LegType = [swaps.LegType ~swaps.LegType];
swaps.LegRate = [swaps.LegRateReceiving swaps.LegRatePaying];
swaps.LegReset = ones(size(swaps,1),1);

numSwaps = size(swaps,1);

%%
Settle = datenum('09-Feb-2026'); % this date is common to both curves

% USD curve

Tenor_usd = [3 6 12 5*12 7*12 10*12 20*12 30*12]';
ZeroRates_usd = [0.036172 0.0359619 0.0344352  0.0349528 0.0365074 0.0385808 0.0428321 0.0424515]';

ZeroDates_usd = datemnth(Settle,Tenor_usd);
Compounding = 2;
Basis = 0;
RateSpec_usd = intenvset('StartDates', Settle,'EndDates', ZeroDates_usd, ...
    'Rates', ZeroRates_usd,'Compounding',Compounding,'Basis',Basis);

figure;
plot(ZeroDates_usd, ZeroRates_usd, 'o-');
xlabel('Date');
datetick('keeplimits');
ylabel('Zero rate USD');
grid on;
title('Yield Curve USD at Settle Date');

% EUR curve

Tenor_eur = [3 6 12 5*12 7*12 10*12 20*12 30*12]';
ZeroRates_eur = [0.026172 0.0259619 0.0244352  0.0249528 0.0265074 0.0285808 0.0328321 0.0324515]';

ZeroDates_eur = datemnth(Settle,Tenor_eur);
Compounding = 2;
Basis = 0;
RateSpec_eur = intenvset('StartDates', Settle,'EndDates', ZeroDates_eur, ...
    'Rates', ZeroRates_eur,'Compounding',Compounding,'Basis',Basis);

figure;
plot(ZeroDates_eur, ZeroRates_eur, 'o-');
xlabel('Date');
datetick('keeplimits');
ylabel('Zero rate EUR');
grid on;
title('Yield Curve EUR at Settle Date');

%so far so good
%% Number of Monte Carlo simulations
% this block code should be common to both curves
numScenarios = 1000;

% Compute monthly simulation dates, then quarterly dates later.
simulationDates = datemnth(Settle,0:12);
simulationDates = [simulationDates datemnth(simulationDates(end),3:3:74)]';
numDates = numel(simulationDates);

%% Compute Floating Reset Dates
% modify this part since now each leg is fixed rate
floatDates = cfdates(Settle-360,swaps.Maturity,swaps.Period);
swaps.FloatingResetDates = zeros(numSwaps,numDates);
for i = numDates:-1:1
    thisDate = simulationDates(i);
    floatDates(floatDates > thisDate) = 0;
    swaps.FloatingResetDates(:,i) = max(floatDates,[],2);
end


%% Setup LGM 2-Factor Model
%Alpha = 0.3;
%Sigma = 0.015;

%hw1 = HullWhite1F(RateSpec,Alpha,Sigma);

%USD LGM model 

a_usd = 0.3;
b_usd = 0.5;
sigma_usd = 0.015;
eta_usd = 0.006;
rho_usd = -0.7;
 
G2PP_usd = LinearGaussian2F(RateSpec_usd,a_usd,b_usd,sigma_usd,eta_usd,rho_usd);


%EUR LGM model 

a_eur = 0.25;
b_eur = 0.45;
sigma_eur = 0.012;
eta_eur = 0.005;
rho_eur = -0.8;
 
G2PP_eur = LinearGaussian2F(RateSpec_eur,a_eur,b_eur,sigma_eur,eta_eur,rho_eur);



%% ============================================================
%  CORRELATED GBM SIMULATION: EUR rate | USD rate | FX spot
%  Uses Cholesky decomposition to generate correlated dW
%  Framework: Hull-White 1F per currency + GBM for FX
%% ============================================================


%% --- 1. SIMULATION PARAMETERS ---
T        = 5;          % max tenor (years) — driven by 5Y CCS trade
nSteps   = 60;         % monthly steps
nPaths   = 10000;
dt       = T / nSteps;
tGrid    = (0:nSteps) * dt;   % time grid [0, dt, 2dt, ..., T]

%% --- 2. INITIAL MARKET DATA (t=0) ---
r0_USD   = 0.0525;     % USD short rate (e.g., SOFR-implied)
r0_EUR   = 0.0380;     % EUR short rate (e.g., ESTR-implied)
FX0      = 1.0850;     % EUR/USD spot (1 EUR = 1.0850 USD)

%% --- 3. HULL-WHITE PARAMETERS (per currency) ---
% EUR
kappa_EUR = 0.030;     % mean reversion speed
sigma_EUR = 0.0080;    % short rate vol
theta_EUR = r0_EUR;    % long-term mean (simplified: calibrate to curve)

% USD
kappa_USD = 0.050;
sigma_USD = 0.0090;
theta_USD = r0_USD;

% FX (GBM)
sigma_FX  = 0.085;     % EUR/USD vol (~8.5% ATM implied)

%% --- 4. CORRELATION MATRIX (3x3) ---
%  Factors:  [EUR_rate, USD_rate, FX_EURUSD]
%  Typical signs:
%   EUR-USD rates: moderately positive  ~0.60
%   EUR rate-FX:  EUR rate up -> EUR strong -> FX up  ~+0.20
%   USD rate-FX:  USD rate up -> USD strong -> FX down ~-0.15

rho = [1.00,  0.60,  0.20;   % EUR_rate
       0.60,  1.00, -0.15;   % USD_rate
       0.20, -0.15,  1.00];  % FX_EURUSD

% Cholesky decomposition (lower triangular)
L = chol(rho, 'lower');
% Verify: L * L' == rho (should hold to machine precision)
assert(max(max(abs(L * L' - rho))) < 1e-10, 'Cholesky failed');

%% --- 5. ALLOCATE PATH MATRICES ---
r_EUR = zeros(nPaths, nSteps + 1);
r_USD = zeros(nPaths, nSteps + 1);
FX    = zeros(nPaths, nSteps + 1);

r_EUR(:, 1) = r0_EUR;
r_USD(:, 1) = r0_USD;
FX(:, 1)    = FX0;

%% --- 6. MONTE CARLO SIMULATION LOOP ---
for iStep = 1:nSteps

    % --- Generate 3 independent standard normals: [nPaths x 3] ---
    Z = randn(nPaths, 3);          % Z ~ N(0, I_3)

    % --- Apply Cholesky to get correlated increments ---
    % dW = Z * L'  => each row is a correlated [dW_EUR, dW_USD, dW_FX]
    dW = Z * L';                   % [nPaths x 3], correlated
    dW = dW * sqrt(dt);            % scale to dt

    dW_EUR = dW(:, 1);
    dW_USD = dW(:, 2);
    dW_FX  = dW(:, 3);

    % --- EUR short rate: Hull-White 1F (Euler-Maruyama) ---
    r_EUR(:, iStep+1) = r_EUR(:, iStep) ...
        + kappa_EUR * (theta_EUR - r_EUR(:, iStep)) * dt ...
        + sigma_EUR * dW_EUR;

    % --- USD short rate: Hull-White 1F ---
    r_USD(:, iStep+1) = r_USD(:, iStep) ...
        + kappa_USD * (theta_USD - r_USD(:, iStep)) * dt ...
        + sigma_USD * dW_USD;

    % --- FX: GBM under risk-neutral measure ---
    % Drift = (r_USD - r_EUR) * dt   [covered interest rate parity]
    FX_drift = (r_USD(:, iStep) - r_EUR(:, iStep)) * dt;
    FX(:, iStep+1) = FX(:, iStep) .* exp( ...
        FX_drift - 0.5 * sigma_FX^2 * dt + sigma_FX * dW_FX );

end

%% --- 7. DISCOUNT FACTORS FROM SIMULATED RATES ---
% Approximate DF via path-integral of short rates (trapezoidal)
r_USD_avg = 0.5 * (r_USD(:, 1:end-1) + r_USD(:, 2:end));  % [nPaths x nSteps]
r_EUR_avg = 0.5 * (r_EUR(:, 1:end-1) + r_EUR(:, 2:end));

cumR_USD = cumsum(r_USD_avg * dt, 2);   % [nPaths x nSteps]
cumR_EUR = cumsum(r_EUR_avg * dt, 2);

DF_USD = exp(-cumR_USD);    % USD discount factors per path, per step
DF_EUR = exp(-cumR_EUR);    % EUR discount factors per path, per step

%% --- 8. DIAGNOSTIC PLOTS ---
figure('Name','Correlated GBM Simulation','Color','w');

% USD rates
subplot(2,3,1);
plot(tGrid, r_USD(1:200,:)', 'b', 'LineWidth', 0.3, 'Color', [0.2 0.4 0.8 0.15]);
hold on; plot(tGrid, mean(r_USD), 'b-', 'LineWidth', 2.5);
title('USD Short Rate (HW)'); xlabel('Years'); ylabel('Rate');
grid on;

% EUR rates
subplot(2,3,2);
plot(tGrid, r_EUR(1:200,:)', 'Color', [0.8 0.2 0.2 0.15], 'LineWidth', 0.3);
hold on; plot(tGrid, mean(r_EUR), 'r-', 'LineWidth', 2.5);
title('EUR Short Rate (HW)'); xlabel('Years'); ylabel('Rate');
grid on;

% FX paths
subplot(2,3,3);
plot(tGrid, FX(1:200,:)', 'Color', [0.1 0.7 0.3 0.15], 'LineWidth', 0.3);
hold on; plot(tGrid, mean(FX), 'g-', 'LineWidth', 2.5);
title('EUR/USD FX (GBM)'); xlabel('Years'); ylabel('EUR/USD');
grid on;

% Verify correlation (terminal values)
subplot(2,3,4);
dR_EUR = diff(r_EUR, 1, 2);
dR_USD = diff(r_USD, 1, 2);
scatter(dR_EUR(:,30), dR_USD(:,30), 2, 'filled');
xlabel('\DeltaR_{EUR}'); ylabel('\DeltaR_{USD}');
title(sprintf('EUR-USD Rate Corr: %.3f (target %.2f)', ...
    corr(dR_EUR(:,30), dR_USD(:,30)), rho(1,2)));
grid on;

subplot(2,3,5);
dFX = diff(log(FX), 1, 2);
scatter(dR_USD(:,30), dFX(:,30), 2, 'filled');
xlabel('\DeltaR_{USD}'); ylabel('\DeltaFX');
title(sprintf('USD-FX Corr: %.3f (target %.2f)', ...
    corr(dR_USD(:,30), dFX(:,30)), rho(2,3)));
grid on;

subplot(2,3,6);
scatter(dR_EUR(:,30), dFX(:,30), 2, 'filled');
xlabel('\DeltaR_{EUR}'); ylabel('\DeltaFX');
title(sprintf('EUR-FX Corr: %.3f (target %.2f)', ...
    corr(dR_EUR(:,30), dFX(:,30)), rho(1,3)));
grid on;

sgtitle('Correlated Simulation: EUR rate | USD rate | EUR/USD FX', 'FontSize', 14);

%% --- 9. REPORT SIMULATION STATS ---
fprintf('\n=== SIMULATION DIAGNOSTICS ===\n');
fprintf('Paths: %d | Steps: %d | dt: %.4f yr\n', nPaths, nSteps, dt);
fprintf('\n  Factor        |  t=0     |  E[T=5]  |  Std[T=5]\n');
fprintf('  USD rate      | %.4f  | %.4f  | %.4f\n', r0_USD, mean(r_USD(:,end)), std(r_USD(:,end)));
fprintf('  EUR rate      | %.4f  | %.4f  | %.4f\n', r0_EUR, mean(r_EUR(:,end)), std(r_EUR(:,end)));
fprintf('  EUR/USD FX    | %.4f  | %.4f  | %.4f\n', FX0,    mean(FX(:,end)),    std(FX(:,end)));
fprintf('\nRealized correlation matrix at mid-tenor:\n');
X = [dR_EUR(:,30), dR_USD(:,30), dFX(:,30)];
disp(corr(X));
fprintf('Target correlation matrix:\n');
disp(rho);


%% Use reproducible random number generator (vary the seed to produce
% different random scenarios).
prevRNG = rng(0, 'twister');    % this model is common to both curves

dt = diff(yearfrac(Settle,simulationDates,1)); % this is common to both curvees
nPeriods = numel(dt);   % this is common to both curvees
scenarios = G2PP_usd.simTermStructs(nPeriods, ...
    'nTrials',numScenarios, ...
    'deltaTime',dt);

% Restore random number generator state
rng(prevRNG);

% Compute the discount factors through each realized interest rate
% scenario.
dfactors = ones(numDates,numScenarios);
for i = 2:numDates
    tenorDates = datemnth(simulationDates(i-1),Tenor_usd);
    rateAtNextSimDate = interp1(tenorDates,squeeze(scenarios(i-1,:,:)), ...
        simulationDates(i),'linear','extrap');
    % Compute D(t1,t2)
    dfactors(i,:) = zero2disc(rateAtNextSimDate, ...
        repmat(simulationDates(i),1,numScenarios),simulationDates(i-1),-1,3);
end
dfactors = cumprod(dfactors,1);

%% Inspect a Scenario
i = 20;
figure;
surf(Tenor_usd, simulationDates, scenarios(:,:,i))
axis tight
datetick('y','mmmyy'); 
xlabel('Tenor (Months)');
ylabel('Observation Date');
zlabel('Rates');
ax = gca;
ax.View = [-49 32];
title(sprintf('Scenario %d Yield Curve Evolution\n',i));

%% Compute all mark-to-market values for this scenario. Use an
% approximation function here to improve performance.
values = hcomputeMTMValues(swaps,simulationDates,scenarios,Tenor_usd);


%%  Inspect Scenario Prices

i = 32;
figure;
plot(simulationDates, values(:,:,i));
datetick;
ylabel('Mark-To-Market Price');
title(sprintf('Swap prices along scenario %d', i));

%% View the portfolio value over time.
figure;
totalPortValues = squeeze(sum(values, 2));
plot(simulationDates,totalPortValues);
title('Total MTM Portfolio Value for All Scenarios');
datetick('x','mmmyy')
ylabel('Portfolio Value ($)')
xlabel('Simulation Dates')

%%
[exposures, expcpty] = creditexposures(values,swaps.CounterpartyID, ...
    'NettingID',swaps.NettingID);

%% View the portfolio exposure over time.
figure;
totalPortExposure = squeeze(sum(exposures,2));
plot(simulationDates,totalPortExposure);
title('Portfolio Exposure for All Scenarios');
datetick('x','mmmyy')
ylabel('Exposure ($)')
xlabel('Simulation Dates')

%% Compute the entire portfolio exposure.
portExposures = sum(exposures,2);

% Compute exposure profiles for each counterparty and entire portfolio.
cpProfiles = exposureprofiles(simulationDates,exposures);
portProfiles = exposureprofiles(simulationDates,portExposures);

%% Visualize the portfolio exposure profiles.
figure;
plot(simulationDates,portProfiles.PFE, ...
    simulationDates,portProfiles.MPFE * ones(numDates,1), ...
    simulationDates,portProfiles.EE, ...
    simulationDates,portProfiles.EPE * ones(numDates,1), ...
    simulationDates,portProfiles.EffEE, ...
    simulationDates,portProfiles.EffEPE * ones(numDates,1));
legend({'PFE (95%)','Max PFE','Exp Exposure (EE)','Time-Avg EE (EPE)', ...
    'Max Past EE (EffEE)','Time-Avg EffEE (EffEPE)'})

datetick('x','mmmyy')
title('Portfolio Exposure Profiles');
ylabel('Exposure ($)')
xlabel('Simulation Dates')

%%
cpIdx = find(expcpty == 4);
figure;
plot(simulationDates,cpProfiles(cpIdx).PFE, ...
    simulationDates,cpProfiles(cpIdx).MPFE * ones(numDates,1), ...
    simulationDates,cpProfiles(cpIdx).EE, ...
    simulationDates,cpProfiles(cpIdx).EPE * ones(numDates,1), ...
    simulationDates,cpProfiles(cpIdx).EffEE, ...
    simulationDates,cpProfiles(cpIdx).EffEPE * ones(numDates,1));
legend({'PFE (95%)','Max PFE','Exp Exposure (EE)','Time-Avg EE (EPE)', ...
    'Max Past EE (EffEE)','Time-Avg EffEE (EffEPE)'})

datetick('x','mmmyy','keeplimits')
title(sprintf('Counterparty %d Exposure Profiles',cpIdx));
ylabel('Exposure ($)')
xlabel('Simulation Dates')

%% Get the discounted exposures per counterparty, for each scenario.
discExp = zeros(size(exposures));
for i = 1:numScenarios
    discExp(:,:,i) = bsxfun(@times,dfactors(:,i),exposures(:,:,i));
end

% Discounted expected exposure
discProfiles = exposureprofiles(simulationDates,discExp, ...
    'ProfileSpec','EE');

%% Aggregate the discounted EE for each counterparty into a matrix.
discEE = [discProfiles.EE];

% Portfolio discounted EE
figure;
plot(simulationDates,sum(discEE,2))
datetick('x','mmmyy','keeplimits')
title('Discounted Expected Exposure for Portfolio');
ylabel('Discounted Exposure ($)')
xlabel('Simulation Dates')

%% Counterparty discounted EE
figure;
plot(simulationDates,discEE)
datetick('x','mmmyy','keeplimits')
title('Discounted Expected Exposure for Each Counterparty');
ylabel('Discounted Exposure ($)')
xlabel('Simulation Dates')

%% Import CDS market information for each counterparty.
CDS = readtable(swapFile,'Sheet','CDS Spreads');
disp(CDS);

%%
CDSDates = datenum(CDS.Date);
CDSSpreads = table2array(CDS(:,2:end));

ZeroData = [RateSpec_usd.EndDates RateSpec_usd.Rates];

% Calibrate default probabilities for each counterparty
DefProb = zeros(length(simulationDates), size(CDSSpreads,2));
for i = 1:size(DefProb,2)
    probData = cdsbootstrap(ZeroData, [CDSDates CDSSpreads(:,i)], ...
        Settle, 'probDates', simulationDates);
    DefProb(:,i) = probData(:,2);
end

% Plot of the cumulative probability of default for each counterparty.
figure;
plot(simulationDates,DefProb)
title('Default Probability Curve for Each Counterparty');
xlabel('Date');
grid on;
ylabel('Cumulative Probability')
datetick('x','mmmyy')
ylabel('Probability of Default')
xlabel('Simulation Dates')

%%
Recovery = 0.4;
CVA = (1-Recovery) * sum(discEE(2:end,:) .* diff(DefProb));
for i = 1:numel(CVA)
    fprintf('CVA for counterparty %d = $%.2f\n',i,CVA(i));
end

%%
figure;
bar(CVA);
title('CVA for Each Counterparty');
xlabel('Counterparty');
ylabel('CVA $');
grid on;


